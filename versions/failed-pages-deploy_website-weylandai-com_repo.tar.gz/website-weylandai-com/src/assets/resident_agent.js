/**
 * resident_agent.js
 * Evaluates current URL, pathname, and venture config metadata.
 * Dynamically determines which layout blocks to subtract based on the active division.
 */

document.addEventListener("DOMContentLoaded", async () => {
    // 1. Evaluate metadata
    const divisionMeta = document.querySelector('meta[name="venture-division"]');
    const division = divisionMeta ? divisionMeta.content : 'unknown';
    
    // Add dynamic CSS class for subtraction
    const style = document.createElement('style');
    style.textContent = '.pruned { display: none !important; }';
    document.head.appendChild(style);

    // 2. Determine layout blocks to subtract based on active division
    const subtractIds = [];
    
    if (division === 'finance') {
        subtractIds.push('media-viewport', 'code-terminal', 'code-sandboxes');
        // Keep telemetry, payment gate, and ledger components
    } else if (division === 'education') {
        subtractIds.push('developer-terminals', 'cap-tables');
        // Keep media viewport, chat conduit, and lesson progress indicators
    } else if (division === 'defense') {
        subtractIds.push('public-pricing-grids', 'sign-ups', 'social-proof');
        // Keep encrypted access portals and secure telemetry
    }
    
    // Perform subtraction
    subtractIds.forEach(id => {
        const el = document.getElementById(id);
        if (el) {
            el.classList.add('pruned');
        }
    });

    // 3. Connect to the local Qwen-local adapter at localhost:11435 or the edge gateway
    // to fetch real-time suggestions from the resident model.
    try {
        const payload = {
            url: window.location.href,
            pathname: window.location.pathname,
            division: division,
            subtracted: subtractIds
        };
        
        // Attempt local adapter first
        fetch('http://localhost:11435/v1/chat/completions', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                model: 'qwen-local',
                messages: [
                    { role: 'system', content: 'Resident Agent Active.' },
                    { role: 'user', content: JSON.stringify(payload) }
                ]
            })
        }).then(response => {
            console.log('[Resident Agent] Local Qwen connection successful.');
        }).catch(err => {
            console.warn('[Resident Agent] Local Qwen unavailable, attempting edge gateway...', err);
            // Fallback to edge gateway
            fetch('https://edge-gateway.johnmobley99.workers.dev/resident', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(payload)
            }).then(res => {
                console.log('[Resident Agent] Edge gateway connection successful.');
            }).catch(edgeErr => {
                console.error('[Resident Agent] Edge gateway also unavailable.', edgeErr);
            });
        });
    } catch (e) {
        console.error('[Resident Agent] Telemetry connection failed.', e);
    }
});
