#!/bin/bash
# ════════════════════════════════════════════════════════════════════════════
# ATTRACTOR DAEMON FOR: COMPANY_MATRIX
# VENTURE: weylandai
# ════════════════════════════════════════════════════════════════════════════
# This script acts as a gravitational sink. It delegates the omni-search 
# capability directly to Mobley, leveraging Exosuit/Pensieve to scan the 
# ENTIRE Mac and Dell architectures simultaneously.

TARGET_DIR=$(pwd)

echo "[*] Activating Exosuit/Pensieve Attractor Field for: COMPANY_MATRIX"
echo "[*] Directing Mobley to scan Mac and Dell disks..."

mobley --agent exosuit --directive "Activate Pensieve. Scan the entire physical disk of this Mac and the Dell server for any logic, markdown specs, scripts, or assets conceptually related to the keywords: [construction_engine, automation_core, company_matrix, robotics_hub, weylandai]. Once identified, symlink or copy the relevant artifacts directly into $TARGET_DIR."

echo "[*] Attractor Cycle Complete. Artifacts assimilated."
